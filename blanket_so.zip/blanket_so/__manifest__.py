# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Blanket Sale Orders',
    'version': '1.0',
    'category': 'Sales',
    'description': """
Blanket Sales Orders
============================================

    Blanket Sales Orders
    """,
    'depends': ['sale_stock'],
    #'website': 'https://www.odoo.com/page/accounting',
    'data': [
        'wizard/blanket_split_view.xml',
        'views/sale_view.xml',
    ],
    'auto_install': False
}
