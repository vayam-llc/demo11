from odoo import models, fields, api
from odoo.tools.translate import _
from odoo.addons import decimal_precision as dp

class BlanketSoSplitLine(models.TransientModel):
    _name = "blanket.so.split.line"
    _rec_name = 'product_id'

    product_id = fields.Many2one('product.product', string="Product", required=True, domain="[('id', '=', product_id)]")
    quantity = fields.Float("Quantity", digits=dp.get_precision('Product Unit of Measure'), required=True)
    wizard_id = fields.Many2one('blanket.so.split', string="Wizard")
    sale_line_id = fields.Many2one('sale.order.line', "Sale line")


class BlanketSoSplit(models.TransientModel):
    _name = 'blanket.so.split'
    _description = 'Blanket Split'

    order_id = fields.Many2one('sale.order')
    date = fields.Date(string='Date', default=fields.Date.context_today, required=True)
    line_ids = fields.One2many('blanket.so.split.line', 'wizard_id', 'Split Lines')

    @api.model
    def default_get(self, fields):
        res = super(BlanketSoSplit, self).default_get(fields)
        order = self.env['sale.order'].browse(self.env.context.get('active_id'))
        split_lines = []
        if order:
            res.update({'order_id': order.id})
            for line in order.order_line:
                split_lines.append((0, 0, {'sale_line_id': line.id, 'product_id': line.product_id.id, 'quantity': line.product_uom_qty}))
            if 'line_ids' in fields:
                res.update({'line_ids': split_lines})
        return res
    
    @api.multi
    def split_order(self):
        blanket_split = True
        for split_line in self.line_ids:
            if  split_line.sale_line_id in self.order_id.order_line:
                
                #if not self.order_id.state!='sale':
                self.order_id.write({
                    'state': 'sale',
                    'confirmation_date': fields.Datetime.now(),
                    'blanket_so': True
                    })
                split_line.sale_line_id._action_launch_procurement_rule()
        

        return {'type': 'ir.actions.act_window_close'}
